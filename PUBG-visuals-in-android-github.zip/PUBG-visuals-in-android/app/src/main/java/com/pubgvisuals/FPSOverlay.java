package com.pubgvisuals;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.view.View;

public class FPSOverlay extends View {

    private Paint paint;
    private long lastTime;
    private int frames;
    private int fps;

    public FPSOverlay(Context context) {
        super(context);
        paint = new Paint();
        paint.setColor(Color.GREEN);
        paint.setTextSize(40);
        paint.setAntiAlias(true);
        lastTime = System.currentTimeMillis();
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);

        frames++;
        long now = System.currentTimeMillis();
        if (now - lastTime >= 1000) {
            fps = frames;
            frames = 0;
            lastTime = now;
        }

        canvas.drawText(fps + " FPS", 50, 100, paint);
        invalidate();
    }
}
