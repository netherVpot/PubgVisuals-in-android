package com.pubgvisuals;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.ArrayAdapter;
import androidx.appcompat.app.AppCompatActivity;

public class SettingsActivity extends AppCompatActivity {

    private SharedPreferences prefs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        prefs = getSharedPreferences("settings", MODE_PRIVATE);

        SeekBar opacityBar = findViewById(R.id.opacity_bar);
        Spinner colorSpinner = findViewById(R.id.color_spinner);
        Spinner ratioSpinner = findViewById(R.id.ratio_spinner);

        String[] colors = {"Красный", "Оранжевый", "Жёлтый", "Зелёный", "Голубой", "Фиолетовый"};
        ArrayAdapter<String> colorAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, colors);
        colorSpinner.setAdapter(colorAdapter);

        String[] ratios = {"16:9", "18:9", "19.5:9", "21:9", "4:3"};
        ArrayAdapter<String> ratioAdapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, ratios);
        ratioSpinner.setAdapter(ratioAdapter);

        opacityBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                prefs.edit().putInt("filter_opacity", progress).apply();
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) {}
        });
    }
}
